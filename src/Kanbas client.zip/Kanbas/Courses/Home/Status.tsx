export default function CourseStatus() {
    return (
      <div id="wd-course-status">
        
      </div>
  );}
  
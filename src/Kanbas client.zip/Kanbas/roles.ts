export enum UserRole {
    FACULTY = "FACULTY",
    STUDENT = "STUDENT",
    ADMIN = "ADMIN",
    USER="USER"
  }